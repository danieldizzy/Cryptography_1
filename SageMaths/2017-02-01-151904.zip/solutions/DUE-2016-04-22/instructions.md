# Instructions for Homework due 2016-04-22

**Problem 1.**
Reproduce the file problem-1/answer-1.pdf by creating a LaTeX
file called problem-1.tex whose output looks just like answer-1.pdf.


**Problem 2.**
Reproduce the file problem-2/answer-2.pdf by creating a LaTeX
file called problem-2.tex whose output looks just like answer-2.pdf.


**Problem 3.**
Reproduce the file problem-3/answer-3.pdf by creating a LaTeX
file called problem-3.tex whose output looks just like answer-3.pdf.


**Problem 4.**
The latex document problem-4/problem-4.tex is a mess. It's full of errors and won't compile.  Fix them all to get it to compile.


**Problem 5.**
Search the internet for a cool example of something you can create using LaTeX and put it in a LaTeX document problem-5/problem-5.tex.  Get it to work there.