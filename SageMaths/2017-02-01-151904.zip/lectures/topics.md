# Topics - 1 week each

1. Introduction to SageMath: sage worksheets, markdown (links, math in dollar signs)
1. Python
1. Cython
1. Latex
1. Symbolic calculus
1. (Exact) Linear algebra
1. Pandas, Statsmodels, Numpy (2 weeks)
1. Number theory / public-key cryptography
