Screencasts of my computer during lectures:

- March 28, 2016: Introduction -- https://youtu.be/SgHPuLPkiwo
- March 30, 2016: SageMathCloud tutorial (part 1 of 2) -- https://youtu.be/tZvvHLK3RKA
- April 1, 2016: SageMathCloud tutorial (part 2 of 2) -- https://youtu.be/0olw3EbVeMg
- April 4, 2016: Basic Python (part 1 of 3) -- https://youtu.be/VYIP9EhtDAg
- April 6, 2016: Basic Python (part 2 of 3) -- https://youtu.be/Yec6Zbpn9ck
- April 8, 2016: Basic Python (part 3 of 3) -- https://youtu.be/GL5l-oMGVUc

- April 11, 2016: Speed (part 1 of 3) -- too much of a disaster to post
- April 13, 2016: Speed (part 2 of 3) -- https://youtu.be/KNwPEf_z9W8
- April 15, 2016: Speed (part 3 of 3) --

- April 18, 2016: Latex (part 1 of 2) -- https://youtu.be/cTAAFKAiZ0M
- April 20, 2016: Latex (part 2 of 2) -- https://youtu.be/a06SyNn8zj0

- April 25, 2016: Calculus (part 1 of 3) -- https://youtu.be/1wQ0rc5s04k
- April 27, 2016: Calculus (part 2 of 3) -- https://youtu.be/g8DI9eRgnBw
- April 29, 2016: Calculus (part 3 of 3) -- https://youtu.be/D26baInqsdQ

- May 2, 2016: Linear algebra (part 1 of 3) -- https://youtu.be/TX5Gk9YTA1M
- May 4, 2016: Linear algebra (part 2 of 3) -- no video due to technical difficulties
- May 6, 2016: Linear algebra (part 3 of 3-- multimodular linear algebra) -- https://youtu.be/xZt0FjB4dy0

- May 9, 2016: Pandas (part 1 of 3) -- https://youtu.be/yt32sXV3mXE
- May 11, 2016: Pandas (part 2 of 3) -- https://youtu.be/hV95G_iqvfc__
- May 13, 2016: statsmodels and scikit-learn (part 3 of 3) -- https://youtu.be/Q3tpIs5E2Ec

- May 16, 2016: Numpy/scipy/matplotlib (part 1 of 3) -- https://youtu.be/HjWTzemCEOk
- May 18, 2016: Numpy vs Sage (part 2 of 3) -- https://youtu.be/km9Nk1K-wgM
- May 20, 2016: Numerical stuff (part 3) -- https://youtu.be/eqPaNLoPk30

- May 23, 2016: Public key crypt - DH (part 1 of 3) -- https://youtu.be/anlQ91mcbCc
- May 25, 2016: Public key crypt - RSA (part 2 of 3) -- https://youtu.be/yCAoPhcAeTE
- May 27, 2016: Public key elliptic curve crypto (part 3 of 3) -- https://youtu.be/cwZer5Mo1wo